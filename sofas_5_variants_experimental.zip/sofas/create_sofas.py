import bpy,bmesh,math,random,json,pathlib,os
from mathutils import Vector
OUT=pathlib.Path(__file__).resolve().parent;random.seed(137)
NAMES=['01_Lagoon','02_Atelier','03_Ribbon','04_Loft','05_Bloom']
TITLES=['Лагуна','Ателье','Лента','Лофт','Цветение']
SEATS=[-.75,0,.75];checks=[]
def materials():
 mats=[]
 for k in range(16):
  m=bpy.data.materials.new('Atlas_%02d'%k);m.use_nodes=True;n=m.node_tree.nodes;links=m.node_tree.links;p=n.get('Principled BSDF')
  tx=n.new('ShaderNodeTexImage');tx.image=bpy.data.images.load(str(OUT/'sofa_materials.png'),check_existing=True);links.new(tx.outputs['Color'],p.inputs['Base Color'])
  p.inputs['Roughness'].default_value=.78 if k in (0,1,2,4) else (.4 if k in (3,9,10,15) else .53)
  if k in (7,8):p.inputs['Metallic'].default_value=.85;p.inputs['Roughness'].default_value=.33
  if k in (0,1,2,4):p.inputs['Sheen Weight'].default_value=.2
  mats.append(m)
 return mats
def finish(o,name,k,bevel=0,segments=3,smooth=False):
 bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;o.name=name
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.clear();o.data.materials.append(MATS[k])
 if bevel:
  mod=o.modifiers.new('Manufactured rounded edges','BEVEL');mod.width=bevel;mod.segments=segments;bpy.ops.object.modifier_apply(modifier=mod.name)
 if smooth:
  for p in o.data.polygons:p.use_smooth=True
  if bevel:
   mod=o.modifiers.new('Weighted surface normals','WEIGHTED_NORMAL');mod.keep_sharp=True;bpy.ops.object.modifier_apply(modifier=mod.name)
 bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(island_margin=.015);bpy.ops.object.mode_set(mode='OBJECT')
 for v in o.data.uv_layers.active.data:v.uv=((k%4+.025+v.uv.x*.95)/4,(k//4+.025+v.uv.y*.95)/4)
 return o
def box(name,loc,size,k,bevel=.008,segments=3,smooth=True):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.dimensions=size;return finish(o,name,k,bevel,segments,smooth)
def cushion(name,loc,size,k,r=.065):return box(name,loc,size,k,min(r,min(size)*.44),5,True)
def sphere(name,loc,size,k,rotation=None,segments=12,rings=8):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=segments,ring_count=rings,radius=1,location=loc);o=bpy.context.object;o.scale=tuple(v/2 for v in size);finish(o,name,k,0,smooth=True)
 if rotation:o.rotation_euler=rotation
 return o
def cylinder(name,loc,r,depth,k,vertices=24):
 bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=r,depth=depth,location=loc);return finish(bpy.context.object,name,k,.003,2,True)
def rod(name,a,b,r,k,vertices=10):
 a,b=Vector(a),Vector(b);bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=r,depth=(b-a).length,location=(a+b)/2);o=bpy.context.object;finish(o,name,k,0,smooth=True);o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o
def path_tube(name,points,r,k,cyclic=False,res=6):
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=1;cu.bevel_depth=r;cu.bevel_resolution=1;cu.use_fill_caps=True
 s=cu.splines.new('POLY');s.points.add(len(points)-1)
 for q,p in zip(s.points,points):q.co=(*p,1)
 s.use_cyclic_u=cyclic;o=bpy.data.objects.new(name,cu);bpy.context.collection.objects.link(o);bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.convert(target='MESH')
 bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.000001);boundary=[e for e in bm.edges if e.is_boundary]
 if boundary:bmesh.ops.holes_fill(bm,edges=boundary,sides=0)
 bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(o.data);bm.free()
 finish(o,name,k,0,smooth=True);return o
def seat_piping(x,y,z,w,d,k):
 pts=[];rad=.065
 for cx,cy,start in [(x+w/2-rad,y+d/2-rad,0),(x-w/2+rad,y+d/2-rad,90),(x-w/2+rad,y-d/2+rad,180),(x+w/2-rad,y-d/2+rad,270)]:
  for i in range(5):
   a=math.radians(start+i*90/4);pts.append((cx+rad*math.cos(a),cy+rad*math.sin(a),z))
 return path_tube('Upholstery piping',pts,.0025,k,True)
def lathe(name,x,y,z,profile,k,n=24):
 vs=[];fs=[]
 for rr,hh in profile:
  for i in range(n):a=2*math.pi*i/n;vs.append((x+rr*math.cos(a),y+rr*math.sin(a),z+hh))
 for j in range(len(profile)-1):
  for i in range(n):fs.append((j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i))
 # Separate inner and outer bottom faces close the hollow vessel's wall.
 fs.extend([tuple(reversed(range(n))),tuple((len(profile)-1)*n+i for i in range(n))])
 me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);return finish(o,name,k,0,smooth=True)
def vase(x,y,z,k=15,height=.17):
 profile=[(.036,0),(.048,.025),(.050,.075),(.037,.115),(.025,.15),(.028,.17),(.022,.17),(.019,.15),(.031,.115),(.044,.075),(.042,.025),(.030,.008)]
 return lathe('Hollow ceramic vase',x,y,z,[(r,h*height/.17) for r,h in profile],k)
def flower(x,y,z,k=12,tilt=.0,seed=0):
 rng=random.Random(seed);a=rng.uniform(-math.pi,math.pi);end=(x+math.cos(a)*.035,y+math.sin(a)*.035,z+.22)
 rod('Flower stem',(x,y,z),end,.0022,11,8)
 for h,sgn in [(.07,-1),(.13,1)]:
  aa=a+sgn*1.4;xx=x+.023*math.cos(aa);yy=y+.023*math.sin(aa)
  sphere('Flower leaf',(xx,yy,z+h),(.056,.014,.005),11,(0,-.45,aa),10,6)
 for i in range(7):
  aa=2*math.pi*i/7;loc=(end[0]+.026*math.cos(aa),end[1]+.026*math.sin(aa),end[2]-.004)
  sphere('Flower petal',loc,(.052,.026,.012),k,(0,.15,aa),10,6)
 sphere('Flower centre',end,(.027,.027,.018),13,segments=10,rings=6)
def bouquet(x,y,z,k=12):
 vase(x,y,z,15)
 for i,(dx,dy,h) in enumerate([(-.018,-.008,.00),(.018,.006,.025),(0,.015,-.025)]):flower(x+dx,y+dy,z+.145+h,k,seed=i+17)
def potted_plant(x,y,z):
 lathe('Planter pot',x,y,z,[(.045,0),(.055,.015),(.061,.10),(.055,.105),(.05,.095),(.04,.012)],10)
 cylinder('Soil',(x,y,z+.09),.049,.009,6,16)
 for i in range(7):
  a=i*2.4;end=(x+.055*math.cos(a),y+.055*math.sin(a),z+.19+(i%3)*.025);rod('Plant petiole',(x,y,z+.09),end,.0025,11,8)
  sphere('Broad botanical leaf',(end[0]+.02*math.cos(a),end[1]+.02*math.sin(a),end[2]+.01),(.083,.032,.008),11,(0,-.45,a),12,6)
def succulent(x,y,z):
 lathe('Succulent pot',x,y,z,[(.045,0),(.055,.01),(.058,.065),(.052,.07),(.048,.062),(.037,.008)],10)
 cylinder('Soil',(x,y,z+.058),.047,.009,6,16)
 for ring,n in [(0,8),(1,5)]:
  for i in range(n):
   a=i*2*math.pi/n+ring*.5;rr=.034 if ring==0 else .019
   sphere('Succulent fleshy leaf',(x+rr*math.cos(a),y+rr*math.sin(a),z+.075+ring*.018),(.065-.015*ring,.023,.016),11,(0,-.45-ring*.2,a),10,6)
def books(x,y,z):
 for i,k in enumerate([14,1]):
  h=z+i*.018;box('Table book pages',(x,y,h+.008),(.14,.10,.013),1,.001,1,False)
  for zz in [h,h+.016]:box('Table book cover',(x,y,zz),(.148,.106,.002),k,0,smooth=False)
def bowl(x,y,z):
 lathe('Ceramic bowl',x,y,z,[(.025,0),(.05,.008),(.075,.04),(.073,.045),(.068,.038),(.046,.012),(.02,.008)],10)
 for i in range(3):sphere('Bowl fruit',(x+(i-1)*.025,y+(i%2)*.012,z+.025),(.041,.041,.039),13,segments=10,rings=6)
def standard_seats(k,style=0):
 for i,x in enumerate(SEATS):
  cushion('Seat_%d_support_surface'%i,(x,-.035,.395),(.735,.68,.18),k,.067)
  seat_piping(x,-.035,.452,.72,.66,k)
def back_pads(k,height=.45,y=.30,z=.70,rounded=.055):
 for i,x in enumerate(SEATS):
  o=cushion('Back cushion_%d'%i,(x,y,z),(.73,.19,height),k,rounded);o.rotation_euler.x=-.11
def legs(k=6,z=.22):
 for x in [-1.06,1.06]:
  for y in [-.29,.33]:rod('Splayed leg',(x*1.035,y*1.12,.018),(x,y,z),.027,k,14)
def cushion_decor(x,y,z,k,angle=0):
 o=cushion('Decorative throw pillow',(x,y,z),(.25,.12,.25),k,.045);o.rotation_euler=(.05,-.08,angle)
def lagoon():
 box('Recessed oak plinth',(0,.04,.15),(2.48,.77,.22),5,.065,5)
 cushion('Cloud upholstered base',(0,.02,.27),(2.51,.82,.23),0,.09);standard_seats(0)
 cushion('Continuous upholstered rear support',(0,.395,.54),(2.48,.14,.45),0,.055)
 for x in SEATS:
  o=cushion('Rounded cloud back',(x,.33,.715),(.79,.26,.48),0,.11);o.rotation_euler.x=-.08
 cushion('Pillowy left arm',(-1.23,.03,.50),(.24,.81,.38),0,.10)
 # Cantilever ties the built-in table to the same oak base.
 box('Integrated table cantilever',(1.27,.10,.22),(.40,.32,.10),5,.025)
 cylinder('Oak drum table',(1.31,.08,.385),.19,.39,5,32)
 cylinder('Round inset tabletop',(1.31,.08,.59),.215,.037,9,40)
 bouquet(1.34,.12,.610,12);books(1.25,-.045,.613)
 cushion_decor(-.98,.20,.63,1,.25)
def atelier():
 legs(6,.25);box('Walnut platform',(0,.035,.25),(2.60,.85,.13),6,.025)
 for y in [-.33,.38]:box('Platform edge rail',(0,y,.24),(2.62,.045,.16),6,.012)
 for x in [-1.25,1.25]:
  for yy in [-.24,.29]:box('Arm post',(x,yy,.43),(.045,.05,.35),6,.008)
  box('Wood arm rail',(x,.025,.61),(.13,.72,.055),6,.013)
 for i in range(13):box('Exposed back slat',(-1.17+i*.195,.43,.57),(.037,.045,.57),6,.008)
 box('Back cap rail',(0,.43,.87),(2.45,.065,.06),6,.015)
 standard_seats(1);back_pads(1,.41,.30,.68,.045)
 box('Integrated wide left tabletop',(-1.32,.035,.617),(.38,.65,.055),5,.035,4)
 potted_plant(-1.34,.20,.645);books(-1.32,-.14,.646)
 cushion_decor(.96,.20,.63,2,-.16)
def panel(name,pts,y,depth,k):
 n=len(pts);vs=[(x,yy,z) for yy in [y-depth/2,y+depth/2] for x,z in pts];fs=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);return finish(o,name,k,.012,3,True)
def ribbon():
 legs(5,.22);box('Oak ribbon seat platform',(0,.02,.245),(2.65,.85,.15),5,.055,5)
 pts=[(-1.28,.23),(1.28,.23)]
 for i in range(33):
  x=1.28-i*2.56/32;zz=.83+.10*math.cos(x*math.pi/1.4)+.035*math.sin(x*5);pts.append((x,zz))
 panel('Continuous wavy oak back shell',pts,.395,.10,5)
 standard_seats(2)
 for x in SEATS:
  for dx in [-.183,.183]:cushion('Vertical upholstered channel',(x+dx,.285,.685),(.36,.17,.41),2,.065)
 cushion('Rounded right arm',(1.24,.03,.49),(.18,.78,.32),2,.074)
 # Fixed flower box forms the right arm's rear portion.
 box('Built-in flower planter',(1.29,.20,.59),(.31,.37,.20),5,.025)
 box('Planter inset soil',(1.29,.20,.691),(.245,.30,.008),6,.01)
 for i in range(3):flower(1.26+(i-1)*.055,.19,.695+(i%2)*.025,13,seed=i+70)
 rod('Side table pedestal',(-1.31,-.02,.12),(-1.31,-.02,.57),.035,8,16)
 box('Pedestal connection to sofa',(-1.25,.04,.24),(.30,.22,.07),5,.02)
 o=cylinder('Oval built-in side table',(-1.31,-.02,.595),.20,.04,5,32);o.scale.y=1.45
 bowl(-1.31,-.02,.618)
def loft():
 for x in [-1.22,1.22]:
  points=[(x,-.36,.07),(x,.39,.07),(x,.42,.78),(x,.38,.84)]
  path_tube('Steel sled and rear upright',points,.019,7)
  rod('Sled front support',(x,-.31,.07),(x,-.31,.30),.019,7)
 for y,z in [(-.32,.29),(.37,.29),(.40,.83)]:rod('Tubular cross rail',(-1.23,y,z),(1.23,y,z),.017,7)
 for x in [-1.20,1.20]:
  for y in [-.27,.29]:rod('Arm stanchion',(x,y,.28),(x,y,.59),.015,7)
  cushion('Leather arm rest',(x,.015,.615),(.15,.69,.085),3,.03)
 box('Leather underframe',(0,.025,.285),(2.39,.77,.12),3,.035)
 standard_seats(3);back_pads(3,.37,.29,.675,.045)
 for x in SEATS:
  for dx in [-.17,.17]:sphere('Tuft button',(x+dx,.181,.69),(.016,.009,.016),6,segments=8,rings=6)
 for x in [-1.05,-.35,.35,1.05]:box('Exposed back upholstery strap',(x,.405,.60),(.065,.025,.43),3,.004)
 box('Built-in black table frame',(1.31,.05,.59),(.37,.55,.055),7,.015)
 box('Inset walnut tabletop',(1.31,.05,.621),(.33,.51,.018),6,.008)
 rod('Table fixed bracket',(1.20,.05,.30),(1.31,.05,.59),.018,7)
 succulent(1.32,.19,.631);books(1.31,-.10,.632)
 cushion_decor(-.95,.18,.62,1,.18)
def bloom():
 # Scalloped silhouette: seven individual padded petals on a brass back frame.
 for x in [-1.04,1.04]:
  for y in [-.28,.32]:cylinder('Brass tapered-look leg',(x,y,.11),.022,.22,8,16)
 box('Brass floating lower rail',(0,.035,.21),(2.62,.81,.08),8,.025)
 cushion('Velvet upholstered body',(0,.025,.29),(2.60,.81,.17),4,.065)
 box('Rear petal anchor rail',(0,.36,.49),(2.56,.09,.30),8,.04)
 standard_seats(4)
 for i in range(7):
  x=(i-3)*.354;h=.43+.13*math.cos(x*math.pi/2.3)
  cushion('Scalloped velvet back petal',(x,.31,.43+h/2),(.35,.205,h),4,.088)
 cushion('Right rolled velvet arm',(1.245,.015,.515),(.18,.77,.29),4,.082)
 # Fluted pedestal and marble tablet share a fixed bracket with the seat base.
 box('Side table brass bracket',(-1.26,.05,.22),(.35,.25,.065),8,.02)
 cylinder('Fluted pedestal core',(-1.31,.04,.36),.13,.37,5,28)
 for i in range(16):
  a=2*math.pi*i/16;cylinder('Pedestal fluting',(-1.31+.128*math.cos(a),.04+.128*math.sin(a),.36),.012,.37,5,10)
 cylinder('Marble built-in tabletop',(-1.31,.04,.563),.211,.04,9,36)
 bouquet(-1.33,.12,.586,12);books(-1.27,-.08,.586)
 cushion_decor(.97,.20,.63,13,-.16)
def setup():
 for o in list(bpy.data.objects):bpy.data.objects.remove(o,do_unlink=True)
 for c in list(bpy.data.collections):
  if c.name!='Collection':bpy.data.collections.remove(c)
 s=bpy.context.scene;s.render.engine='BLENDER_EEVEE_NEXT';s.eevee.taa_render_samples=32;s.render.resolution_x=1000;s.render.resolution_y=700;s.render.resolution_percentage=100;s.world.color=(.3,.3,.3);s.view_settings.view_transform='AgX'
 return s
def light(loc,power,size):
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector((0,0,.5))-o.location).to_track_quat('-Z','Y').to_euler()
selected=os.environ.get('SOFA_VARIANTS')
if selected and (OUT/'model_checks.json').exists():checks=json.loads((OUT/'model_checks.json').read_text())
for idx,build in enumerate([lagoon,atelier,ribbon,loft,bloom]):
 if selected and str(idx+1) not in selected.split(','):continue
 scene=setup();MATS=materials();build();model=[o for o in scene.objects if o.type=='MESH'];main=bpy.data.collections.new('LOD0_Model');scene.collection.children.link(main)
 root=bpy.data.objects.new('Template_Seat_Height_Correction',None);bpy.context.collection.objects.link(root)
 for o in model:o.parent=root
 root.scale.z=.4251/.485;bpy.context.view_layer.update()
 for o in model:
  for c in list(o.users_collection):c.objects.unlink(o)
  main.objects.link(o);bpy.context.view_layer.objects.active=o;bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT')
 for level,ratio in [(1,.55),(2,.28)]:
  coll=bpy.data.collections.new('LOD%d_Authoring'%level);scene.collection.children.link(coll)
  for original in model:
   if level==2 and original.name.startswith(('Upholstery piping','Tuft button')):continue
   o=original.copy();o.data=original.data.copy();coll.objects.link(o);o.name=original.name+'_LOD%d'%level
   if len(o.data.polygons)>12:
    dec=o.modifiers.new('Distance simplification','DECIMATE');dec.ratio=ratio;bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=dec.name)
  coll.hide_render=True;coll.hide_viewport=True
 for level in range(3):
  source=main if level==0 else bpy.data.collections['LOD%d_Authoring'%level];coll=bpy.data.collections.new('Shadow_LOD%d'%level);scene.collection.children.link(coll)
  for original in source.objects:
   o=original.copy();o.data=original.data.copy();coll.objects.link(o)
  coll.hide_render=True;coll.hide_viewport=True
 # Keep the original 55-bone rig externally in the package; reference markers
 # in the authoring file document the three adult butt targets.
 markers=bpy.data.collections.new('Reference_Seat_Targets');scene.collection.children.link(markers)
 for i,x in enumerate(SEATS):
  o=bpy.data.objects.new('Seat_%d_IK_butt_target'%i,None);o.location=(x,-.05,.485);o.empty_display_type='PLAIN_AXES';o.empty_display_size=.08;markers.objects.link(o)
 tri=sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in model);bad=0
 for o in model:
  bm=bmesh.new();bm.from_mesh(o.data);bad+=sum(not e.is_manifold for e in bm.edges);bm.free()
 record={'model':NAMES[idx],'lod0_triangles':tri,'non_manifold_edges':bad,'all_uv_present':all(bool(o.data.uv_layers) for o in model),'seat_target_height_m':.485,'seat_surface_height_m':.4251,'seat_centres_x_m':SEATS,'game_tested':False};checks=[v for v in checks if v['model']!=NAMES[idx]];checks.append(record);checks.sort(key=lambda x:x['model'])
 # Neutral studio material is separate from the export collection.
 floor=box('Studio floor',(0,0,-.035),(200,200,.05),1,0,smooth=False);mat=bpy.data.materials.new('Studio neutral');mat.diffuse_color=(.58,.56,.51,1);floor.data.materials.clear();floor.data.materials.append(mat)
 light((-3,-4,5),650,4);light((3,-1,3),400,3);light((0,3,4),550,3)
 bpy.ops.object.camera_add(location=(3.8,-5.4,3.0));cam=bpy.context.object;cam.data.type='ORTHO';cam.data.ortho_scale=3.85;scene.camera=cam;target=Vector((0,0,.47));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler()
 scene['delivery_status']='Experimental Sims 4 sofa authoring asset';scene['seat_target_height']=.485;scene['seat_target_x']=SEATS;scene['game_tested']=False
 for im in bpy.data.images:
  if im.source=='FILE' and im.has_data:im.pack()
 bpy.ops.wm.save_as_mainfile(filepath=str(OUT/(NAMES[idx]+'.blend')))
 (OUT/'model_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
 print('MODEL BUILT',record,flush=True)
 for view,loc in [('front',(0,-6,2.2)),('perspective',(3.8,-5.4,3.0)),('rear',(-3.8,5.4,2.7))]:
  cam.location=loc;cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(OUT/(NAMES[idx]+'_'+view+'.png'));bpy.ops.render.render(write_still=True)
 print('MODEL RENDERED',NAMES[idx],flush=True)
